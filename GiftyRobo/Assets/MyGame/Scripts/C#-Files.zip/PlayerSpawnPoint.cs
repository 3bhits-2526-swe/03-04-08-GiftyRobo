using UnityEngine;

public class PlayerSpawnPoint : MonoBehaviour
{
}