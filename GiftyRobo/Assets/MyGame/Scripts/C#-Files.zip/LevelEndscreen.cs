using UnityEngine;

public class LevelEndscreen : MonoBehaviour
{
    [SerializeField] private Canvas endscreen;
    [SerializeField] private GameState gameState;

    private void Awake()
    {
        endscreen.enabled = false; // garantiert "aus" am Anfang
    }

    private void OnEnable()
    {
        EndLevel.OnLevelComplete += RevealEndscreen;

        // Falls Event schon gefeuert wurde, trotzdem korrekt anzeigen:
        if (gameState != null && gameState.LevelComplete)
            RevealEndscreen();
    }

    private void OnDisable()
    {
        EndLevel.OnLevelComplete -= RevealEndscreen;
    }

    private void RevealEndscreen()
    {
        endscreen.enabled = true;
    }
}
