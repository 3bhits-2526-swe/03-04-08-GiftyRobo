using UnityEngine;

public class GiftSpawnPoint : MonoBehaviour
{
    // ...
}
