using UnityEngine;

public class LevelEndscreenInput : MonoBehaviour
{
    [SerializeField] private InputObjectState joystickLR;
    [SerializeField] private InputObjectState joystickBT;
    [SerializeField] private InputObjectState buttonA;
}